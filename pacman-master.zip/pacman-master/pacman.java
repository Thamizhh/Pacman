/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pacman;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class pacman {

    /**
     * @param args the command line arguments
     */
    
    public static final int NORTH = 0;
    public static final int EAST = 1;
    public static final int SOUTH = 2;
    public static final int WEST = 3;
    int dir;
    int x, y; 
    int width, height;
    String inputDirection;
    pacman man1;
    
    public pacman(int width, int height)
    {
        this.width = width;
        this.height = height;
    }
    
    public void executemain()
    {
        
        Scanner dis=new Scanner(System.in);

        do
        {
            String initialResponse;
            String[] userValues;

            initialResponse = dis.nextLine();

            userValues = initialResponse.split(",");

            x = Integer.parseInt(userValues[0]);
            y = Integer.parseInt(userValues[1]);
            inputDirection = userValues[2];

            //Make sure the values passed are within the specified range
            if(x >5 || x<0 || y >5 || y<0)
            {
                JOptionPane.showMessageDialog(null,"Invalid Input","", JOptionPane.ERROR_MESSAGE);
                System.out.print("Out of range. Please try again ");
                continue;
            }
            break;
        }while(true);

        Scanner userInput = new Scanner(System.in); 
        String input ="";

        int i = 0;

        //Loop continues until the user requests for report
        do
        {
            input = userInput.nextLine();

            if(!input.equalsIgnoreCase("REPORT"))
            {   
                if((input.toUpperCase()).equals("LEFT"))
                {
                    if(i==0)  
                    {
                        if((inputDirection.toUpperCase()).equals("NORTH"))
                        {
                            dir = WEST;
                        }
                        else if((inputDirection.toUpperCase()).equals("EAST"))
                        {
                            dir = SOUTH;
                        }
                        else if((inputDirection.toUpperCase()).equals("SOUTH"))
                        {
                            dir = WEST;
                        }
                        else if((inputDirection.toUpperCase()).equals("WEST"))
                        {
                            dir = NORTH;
                        }
                    }   
                    else  
                    {
                        if(dir == NORTH) 
                        {
                            dir = WEST;
                        }
                        else if(dir == WEST) 
                        {
                            dir = SOUTH;
                        }
                        else if(dir == SOUTH) 
                        {
                            dir = EAST;
                        }
                        else if(dir == EAST) 
                        {
                            dir = NORTH;
                        }
                    }  
                }   
                else if((input.toUpperCase()).equals("RIGHT"))
                {
                    if(i==0)  
                    {
                        if((inputDirection.toUpperCase()).equals("NORTH"))
                        {
                            dir = EAST;
                        }
                        else if((inputDirection.toUpperCase()).equals("EAST"))
                        {
                            dir = SOUTH;
                        }
                        else if((inputDirection.toUpperCase()).equals("SOUTH"))
                        {
                            dir = WEST;
                        }
                        else if((inputDirection.toUpperCase()).equals("WEST"))
                        {
                            dir = NORTH;
                        }
                    }
                    else
                    {
                        if(dir == NORTH) 
                        {
                            dir = EAST;
                        }
                        else if(dir == EAST) 
                        {
                            dir = SOUTH;
                        }
                        else if(dir == SOUTH) 
                        {
                            dir = WEST;
                        }
                        else if(dir == WEST) 
                        {
                            dir = NORTH;
                        }
                    }
                } 
                else if((input.toUpperCase()).equals("MOVE"))
                {
                    if(i == 0)
                    {
                        if((inputDirection.toUpperCase()).equals("NORTH"))
                        {
                            dir = 0;
                        }
                        else if((inputDirection.toUpperCase()).equals("EAST"))
                        {
                            dir = 1;
                        }
                        else if((inputDirection.toUpperCase()).equals("SOUTH"))
                        {
                            dir = 2;
                        }
                        else if((inputDirection.toUpperCase()).equals("WEST"))
                        {
                            dir = 3;
                        }
                    }

                    //change coordinates with respect to input 
                    //and make sure pacman does not fall off the grid
                    if(dir == 1)
                    {
                        int xCopy = x;
                        x = x+1;

                        if(x>5)
                        {
                           x=xCopy;
                        }
                    }
                    else if(dir == 2)
                    {
                        int yCopy = y;
                        y = y-1;

                        if(y<0)
                        {
                           y=yCopy;
                        }
                    }
                    else if(dir == 3)
                    {
                        int xCopy = x;
                        x = x-1;

                        if(x<0)
                        {
                            x=xCopy;
                        }
                    }
                    else if(dir == 0)
                    {
                        int yCopy = y;
                        y = y+1;

                        if(y>5)
                        {
                           y=yCopy;
                        }
                    }
                }               
            }
            else
            {
                String outputString="";

                if(dir == 0)
                {
                    outputString = "NORTH";
                }
                else if(dir == 1)
                {
                    outputString = "EAST";
                }
                else if(dir == 2)
                {
                    outputString = "SOUTH";
                }
                else if(dir == WEST)
                {
                    outputString = "WEST";
                }
                System.out.println("Output: " + x + "," + y + "," + outputString);
            }            
            i++;
        }while (!input.equalsIgnoreCase("REPORT"));
    }

    public static void main(String[] args) 
    {
        // TODO code application logic here
        System.out.print("PLACE ");
        
        pacman man = new pacman(5,5);
        man.executemain();
    }
}
